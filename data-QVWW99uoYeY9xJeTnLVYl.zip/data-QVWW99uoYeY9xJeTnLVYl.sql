DROP TABLE IF EXISTS `cliente`;

CREATE TABLE `cliente` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `region` varchar(50) default NULL,
  `email` varchar(255) default NULL,
  PRIMARY KEY (`id`)
) AUTO_INCREMENT=1;

INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("April Alvarado","Mykolaiv oblast","lectus.a.sollicitudin@icloud.edu"),
  ("Jack Vang","South Island","et.malesuada.fames@hotmail.org"),
  ("Nasim Goodman","Queensland","sagittis@icloud.com"),
  ("Lillian Tate","Warmińsko-mazurskie","sapien.imperdiet@google.ca"),
  ("Fallon Phelps","North Island","sit.amet@aol.com"),
  ("Fatima Watkins","Calabria","enim.sed.nulla@outlook.ca"),
  ("Inga Parker","New South Wales","cursus@google.com"),
  ("Hamish Henson","Drenthe","amet@icloud.couk"),
  ("Barclay Lucas","Orkney","vel@hotmail.edu"),
  ("Bradley Richard","Hamburg","urna.nunc@google.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Nigel Fisher","Zhytomyr oblast","sed@aol.edu"),
  ("Cheyenne Vinson","Pernambuco","bibendum.ullamcorper@icloud.couk"),
  ("Brandon Sexton","Chelyabinsk Oblast","dui.in.sodales@aol.net"),
  ("Hashim King","Lima","eget.ipsum@protonmail.org"),
  ("Gretchen Lowery","Burgenland","nulla.integer@icloud.edu"),
  ("Mason Bryan","Madrid","semper.auctor.mauris@outlook.ca"),
  ("Cadman Schneider","Huáběi","quam.vel.sapien@protonmail.couk"),
  ("Amity Marquez","São Paulo","nec.tellus@yahoo.net"),
  ("Prescott Cobb","Gauteng","vitae@google.couk"),
  ("Fletcher Stokes","North West","turpis.aliquam@yahoo.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Vaughan Robinson","Connacht","urna@yahoo.ca"),
  ("Oprah Schultz","Berlin","suscipit.nonummy@yahoo.ca"),
  ("Cadman Riggs","Xīběi","auctor@outlook.org"),
  ("Scott Lewis","Sokoto","donec@yahoo.edu"),
  ("Cally Holloway","Munster","blandit.viverra.donec@yahoo.couk"),
  ("Aline Dodson","Lubuskie","magnis.dis@yahoo.org"),
  ("Jada Boyer","Bangsamoro","metus.eu.erat@google.org"),
  ("Eleanor Pierce","North Island","lorem.ut@aol.org"),
  ("Elvis Bolton","Michoacán","facilisi.sed@yahoo.couk"),
  ("Cheryl Hodges","Västra Götalands län","ac.feugiat@protonmail.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Kimberly Wilson","New Brunswick","tellus@aol.org"),
  ("Daniel Cameron","Galicia","hendrerit@google.couk"),
  ("Allistair Pugh","Lubuskie","maecenas.libero.est@protonmail.org"),
  ("Macy Pruitt","Puntarenas","nunc.ut.erat@icloud.org"),
  ("Kalia Wagner","North Island","ipsum@yahoo.edu"),
  ("Keaton Morris","Dōngběi","risus@protonmail.ca"),
  ("John Cunningham","North Chungcheong","tellus.lorem@outlook.couk"),
  ("Branden Whitney","Los Ríos","enim.condimentum@icloud.edu"),
  ("Jessica Mayo","Pernambuco","aenean.eget.magna@protonmail.org"),
  ("Jenna Bernard","Daman and Diu","ipsum@hotmail.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Arsenio Morris","Hessen","natoque.penatibus@aol.ca"),
  ("Paula Mayo","Kaduna","est.tempor@google.org"),
  ("William Farrell","łódzkie","dui.suspendisse.ac@outlook.net"),
  ("Leroy Holmes","North Maluku","vel.quam@yahoo.couk"),
  ("Raymond Juarez","Arica y Parinacota","nulla.at@google.ca"),
  ("Mechelle Schultz","Arunachal Pradesh","ipsum.suspendisse@icloud.org"),
  ("Rowan Ochoa","South Jeolla","eu.euismod.ac@hotmail.org"),
  ("Kiayada Fischer","Special Region of Yogyakarta","nec.ante@icloud.org"),
  ("Amaya Kim","Małopolskie","interdum.feugiat.sed@hotmail.net"),
  ("Dillon English","Jeju","metus.in@protonmail.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Charlotte Tate","Illes Balears","nulla.in.tincidunt@aol.net"),
  ("Quon Merritt","Cantabria","maecenas.mi@protonmail.edu"),
  ("Zachary Schneider","Mpumalanga","adipiscing.ligula.aenean@aol.ca"),
  ("Fatima Cooley","Gauteng","nulla.facilisis@hotmail.net"),
  ("Lenore Tyler","Free State","commodo.hendrerit@google.edu"),
  ("Myra Vinson","Dnipropetrovsk oblast","ultricies.ornare@yahoo.com"),
  ("Genevieve Pratt","Gävleborgs län","non.luctus@aol.net"),
  ("Basia Todd","Xīběi","sed@google.net"),
  ("Cain Booth","Vologda Oblast","erat@aol.edu"),
  ("Dolan Whitney","Brussels Hoofdstedelijk Gewest","gravida.sagittis.duis@yahoo.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Tyrone Langley","Sląskie","odio.sagittis@icloud.com"),
  ("Kadeem Battle","British Columbia","eget.tincidunt.dui@icloud.ca"),
  ("Adria Stevenson","Corse","luctus.curabitur.egestas@hotmail.ca"),
  ("Donna Durham","Saratov Oblast","vel.arcu@icloud.couk"),
  ("Desiree Mcmillan","Molise","tempus.non.lacinia@aol.com"),
  ("Mannix Eaton","Provence-Alpes-Côte d'Azur","ante.maecenas.mi@aol.ca"),
  ("Liberty Arnold","Cherkasy oblast","faucibus.leo@yahoo.org"),
  ("Kennedy Hines","Östergötlands län","ante.lectus@aol.edu"),
  ("Ulla Lawson","Aisén","vel.pede.blandit@protonmail.edu"),
  ("Serena Hendricks","Free State","pellentesque.ut@google.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Simone Roach","Cajamarca","vestibulum.mauris.magna@google.net"),
  ("Martha Long","Antwerpen","erat.volutpat@yahoo.net"),
  ("Olympia Bray","Gangwon","sit.amet@outlook.com"),
  ("Fulton Mccoy","Stockholms län","luctus.felis@protonmail.net"),
  ("Brendan O'connor","Chernivtsi oblast","in.felis@protonmail.couk"),
  ("Leila Haney","Queensland","nunc@protonmail.couk"),
  ("Xenos Lawson","Queensland","accumsan.neque@protonmail.org"),
  ("Vivien Shepard","Galicia","ac@icloud.ca"),
  ("Nathaniel Bradshaw","Euskadi","mauris.sapien.cursus@icloud.couk"),
  ("Kirby Oneil","South Island","vulputate@outlook.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Fay Brock","Lambayeque","rutrum.magna.cras@yahoo.edu"),
  ("Gillian Pope","Podlaskie","pede.praesent.eu@google.edu"),
  ("Angelica Rodgers","Yucatán","elit.sed.consequat@outlook.ca"),
  ("Harding Shannon","Xīběi","aliquam.enim@protonmail.couk"),
  ("Luke Nicholson","Mykolaiv oblast","lorem.ipsum@hotmail.couk"),
  ("Rogan Gilbert","North-East Region","id.enim.curabitur@icloud.com"),
  ("Indigo Hines","Huáběi","sodales.mauris@yahoo.edu"),
  ("Raven Payne","Gyeonggi","morbi@outlook.edu"),
  ("Briar Weaver","Bahia","dui@icloud.com"),
  ("Leonard Hodges","Maine","euismod.in@yahoo.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Bevis Zamora","Free State","libero.lacus@outlook.net"),
  ("Marah Riddle","Australian Capital Territory","nunc@hotmail.edu"),
  ("Jarrod Figueroa","Mpumalanga","nunc.sed.orci@protonmail.org"),
  ("Marsden Padilla","Central Luzon","adipiscing.elit.etiam@icloud.ca"),
  ("Nero Zamora","Huádōng","nascetur.ridiculus@aol.ca"),
  ("Naomi Witt","Connacht","viverra.maecenas.iaculis@icloud.org"),
  ("Iris Mckinney","Innlandet","nibh.phasellus.nulla@hotmail.ca"),
  ("Elton Bates","Cordillera Administrative Region","enim.curabitur@icloud.net"),
  ("Hedwig Howe","Nordrhein-Westphalen","fringilla.euismod@hotmail.org"),
  ("Jacqueline Avila","Tyrol","est.ac@hotmail.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Nero Wynn","Ilocos Region","egestas.sed.pharetra@outlook.com"),
  ("Adara Clements","Sverdlovsk Oblast","mi.duis@outlook.net"),
  ("Orli Banks","Andaman and Nicobar Islands","per.conubia@hotmail.org"),
  ("Oren Yates","Vienna","ligula.nullam@protonmail.net"),
  ("Edward Wong","Riau Islands","gravida.non@yahoo.couk"),
  ("Dustin Knox","Podlaskie","dapibus@aol.org"),
  ("Cameran Carlson","East Java","velit.sed@yahoo.org"),
  ("Kylee Randolph","Rogaland","vivamus@icloud.net"),
  ("Melodie Gentry","Jambi","mauris@aol.ca"),
  ("Kerry Warner","Dorset","ipsum.ac@yahoo.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Wang Cohen","Ulster","ante.iaculis@hotmail.com"),
  ("Isadora Ewing","Upper Austria","egestas@hotmail.couk"),
  ("Venus Porter","Stockholms län","ut.nisi@aol.org"),
  ("Deacon Bray","Prince Edward Island","iaculis.nec@outlook.com"),
  ("Cade Joyce","Punjab","cras.vulputate@outlook.couk"),
  ("Scarlett Greer","Lviv oblast","bibendum.sed@icloud.couk"),
  ("Noelle Reese","Sindh","ornare.elit@protonmail.ca"),
  ("Drew Schneider","Henegouwen","congue@outlook.org"),
  ("Lucius Glover","Ankara","ornare.sagittis.felis@protonmail.edu"),
  ("Cora Alexander","Rogaland","leo.elementum@hotmail.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Glenna Mack","Mecklenburg-Vorpommern","gravida.praesent@hotmail.com"),
  ("Adele Cantrell","Zhōngnán","congue.in@outlook.com"),
  ("Dillon Mccoy","O'Higgins","integer@protonmail.couk"),
  ("Quentin Whitfield","West-Vlaanderen","curae.phasellus.ornare@protonmail.edu"),
  ("Avye Wilkinson","Punjab","nibh.lacinia@yahoo.org"),
  ("Roth Blackwell","Maule","lorem.fringilla@protonmail.edu"),
  ("Scarlet Wiley","North-East Region","non@hotmail.net"),
  ("Matthew Harmon","Xīnán","arcu.vestibulum@aol.com"),
  ("Calista Hendrix","Ceuta","auctor.vitae.aliquet@hotmail.net"),
  ("Sebastian Bailey","Hatay","magna@hotmail.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Xavier Sanchez","Northern Territory","nunc@outlook.couk"),
  ("Doris Mccullough","Salzburg","vulputate.dui@yahoo.couk"),
  ("Jonah Harper","South Jeolla","praesent@google.couk"),
  ("Yuri Pierce","Jeju","nisi.dictum@google.net"),
  ("Cameron Houston","Wielkopolskie","pellentesque.eget@google.net"),
  ("Emmanuel Nunez","Rogaland","arcu@protonmail.net"),
  ("Cole Strickland","Vlaams-Brabant","mauris@yahoo.edu"),
  ("Quinlan Bender","Gorontalo","cras@yahoo.org"),
  ("Ivan Estes","Leinster","mollis.integer@google.edu"),
  ("Benjamin Solomon","Saarland","morbi.tristique@aol.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Charity Tate","North Gyeongsang","sit.amet@icloud.edu"),
  ("Amery Dillon","Xīběi","nunc.in@yahoo.net"),
  ("Kelsey Kinney","Namen","tellus@icloud.ca"),
  ("Leilani Sargent","Tamil Nadu","sem.consequat@icloud.com"),
  ("Pamela Walker","Ulster","laoreet@aol.com"),
  ("Plato Swanson","Xīběi","augue.id@outlook.org"),
  ("Louis Armstrong","La Guajira","tincidunt.orci@outlook.com"),
  ("Julian Chan","Connacht","neque@hotmail.net"),
  ("Zachery Rios","Tarapacá","in.tincidunt@icloud.net"),
  ("Aidan Gardner","Burgenland","augue.scelerisque@google.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Adena Snider","Vĩnh Phúc","felis.orci@aol.ca"),
  ("Keegan Boyd","KwaZulu-Natal","facilisis.eget@yahoo.edu"),
  ("Alfreda Howard","Bauchi","eu@aol.net"),
  ("Derek Lang","Lagos","aliquam.ultrices@hotmail.couk"),
  ("Tana David","Sachsen","phasellus.dolor@google.couk"),
  ("Branden Black","Cao Bằng","at@aol.org"),
  ("Kalia Sampson","Quảng Ninh","consectetuer.adipiscing@hotmail.net"),
  ("Pamela Vaughn","Bangsamoro","egestas.aliquam@hotmail.ca"),
  ("Jemima Solis","łódzkie","rutrum.justo.praesent@protonmail.com"),
  ("Yoshio Hamilton","West Region","elit.pretium.et@aol.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Tanek Dotson","Michoacán","dui@protonmail.net"),
  ("Damon Franklin","São Paulo","quisque@google.com"),
  ("Emi Douglas","Friesland","phasellus.at@protonmail.ca"),
  ("Tyler Castillo","Huáběi","orci@yahoo.org"),
  ("Amela Tate","Warmińsko-mazurskie","tellus.imperdiet@google.com"),
  ("Emmanuel O'connor","Nevada","ornare.placerat@outlook.edu"),
  ("Kelsie Curtis","Stockholms län","quisque@aol.net"),
  ("Micah Frederick","Bình Phước","egestas@aol.com"),
  ("Breanna Lowe","Central Region","cum@outlook.edu"),
  ("Arsenio Evans","Amazonas","duis.sit@google.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Chelsea Dejesus","Osun","auctor.velit@hotmail.couk"),
  ("Whoopi Randolph","Trøndelag","dolor.dapibus@icloud.ca"),
  ("Derek Carlson","South Island","nonummy.ut.molestie@icloud.edu"),
  ("Trevor Webster","Kyiv oblast","sit.amet@hotmail.ca"),
  ("Sawyer Mendoza","Cagayan Valley","nisi.nibh.lacinia@hotmail.edu"),
  ("Alexa Rose","New Brunswick","ipsum.suspendisse@protonmail.edu"),
  ("Autumn Turner","West Region","sodales.mauris.blandit@hotmail.couk"),
  ("Quinn Atkinson","Orenburg Oblast","sed.leo@aol.org"),
  ("Isabella Cummings","West-Vlaanderen","integer@protonmail.ca"),
  ("Chava Carroll","North Region","nibh.lacinia@protonmail.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Keiko Potts","Languedoc-Roussillon","neque.nullam@icloud.ca"),
  ("Willow Branch","Central Region","ut.eros@icloud.com"),
  ("Daryl Madden","Utah","eu.ligula.aenean@google.net"),
  ("Andrew Pickett","Newfoundland and Labrador","luctus@protonmail.ca"),
  ("Richard Wolf","Bihar","metus.aliquam@yahoo.couk"),
  ("Honorato Santana","Australian Capital Territory","nisl.elementum@yahoo.net"),
  ("Sydney Frazier","Huáběi","turpis@outlook.ca"),
  ("Omar Campbell","Sindh","porttitor.scelerisque@hotmail.couk"),
  ("Justine Bruce","Paraíba","id.ante@icloud.com"),
  ("Camille Franks","East Kalimantan","posuere.vulputate@aol.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Zachary Clark","North Gyeongsang","dictum.sapien@hotmail.couk"),
  ("Shad Nguyen","Kaduna","donec@google.com"),
  ("Kyle Townsend","Chiapas","nibh.sit@icloud.ca"),
  ("Phoebe Hewitt","Centre","magna.cras@yahoo.ca"),
  ("Hedley Johnston","Overijssel","turpis@aol.com"),
  ("Basia Ruiz","Tabasco","et.malesuada@google.ca"),
  ("Avye Perry","Bauchi","a@outlook.org"),
  ("Nell Wooten","North Jeolla","lorem.ut.aliquam@icloud.couk"),
  ("Armand Hughes","Salzburg","duis.a@yahoo.edu"),
  ("Rose Campbell","Northern Territory","et@hotmail.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Owen Everett","Metropolitana de Santiago","duis@outlook.couk"),
  ("Nathaniel Logan","Kaluga Oblast","rhoncus.id.mollis@aol.com"),
  ("Rinah Herman","Manitoba","elit@outlook.net"),
  ("Linda Knox","Free State","elit.etiam.laoreet@google.edu"),
  ("Nasim Lyons","Munster","varius.orci.in@aol.org"),
  ("Maite Massey","Arequipa","sed.nec.metus@yahoo.com"),
  ("Emerald Morse","Norte de Santander","nullam.vitae.diam@hotmail.edu"),
  ("Julie Chang","Dōngběi","vulputate.ullamcorper.magna@hotmail.com"),
  ("Ruby Garrison","Punjab","arcu.nunc@outlook.edu"),
  ("Xantha Austin","Arkansas","tempor.erat@hotmail.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Jerry Lee","East Region","velit.cras@aol.couk"),
  ("Vanna English","Andalucía","mauris.blandit@hotmail.org"),
  ("Seth Valdez","Missouri","ut@google.com"),
  ("Drew Buchanan","Ivanovo Oblast","dolor.vitae@yahoo.com"),
  ("Maryam Harmon","Balıkesir","id.sapien@hotmail.net"),
  ("Hannah Bonner","Quảng Nam","donec.nibh.quisque@icloud.ca"),
  ("Ariana Mckee","Nunavut","ac.libero@icloud.org"),
  ("Clare Livingston","Bihar","sem.ut@google.org"),
  ("Basil Whitfield","Arequipa","cras.vehicula@google.org"),
  ("Jacqueline Barrett","Nariño","pulvinar.arcu@yahoo.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Elliott Cantu","Noord Brabant","nunc.ut@aol.edu"),
  ("Robert Burnett","Vinnytsia oblast","ac.nulla@protonmail.org"),
  ("Xenos Watkins","Pskov Oblast","facilisis.facilisis.magna@icloud.ca"),
  ("Flavia Underwood","Kirovohrad oblast","tellus.justo.sit@hotmail.ca"),
  ("Mohammad Baxter","Schleswig-Holstein","penatibus.et@yahoo.org"),
  ("Malcolm Allison","Biobío","nibh@icloud.net"),
  ("Cherokee Mullen","South Island","convallis@protonmail.org"),
  ("Calista Pearson","Huáběi","donec@hotmail.ca"),
  ("Elliott Lynch","Aisén","magna.a@yahoo.ca"),
  ("Graiden Wolfe","Jeju","nec@yahoo.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Theodore Cote","Noord Brabant","ipsum.phasellus@outlook.org"),
  ("Adrian Winters","Bình Thuận","venenatis.lacus.etiam@outlook.ca"),
  ("Ulla Todd","Essex","rutrum@aol.net"),
  ("Simone Dorsey","Kharkiv oblast","mauris.ut@icloud.net"),
  ("Alexander Goodman","Oslo","vivamus.non@outlook.edu"),
  ("Darius Lang","Azad Kashmir","lorem.semper.auctor@hotmail.couk"),
  ("Grady Guerrero","Kayseri","volutpat.ornare.facilisis@hotmail.couk"),
  ("Zoe Hancock","Vorarlberg","non.cursus@aol.com"),
  ("Dalton Beard","Brussels Hoofdstedelijk Gewest","quam@aol.edu"),
  ("Oliver Wooten","Zeeland","eu@yahoo.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Mara Holland","Munster","nonummy.ultricies.ornare@yahoo.couk"),
  ("Quintessa Barlow","North Region","et@protonmail.com"),
  ("Leroy Lee","Dōngběi","suspendisse@protonmail.org"),
  ("Avye Maxwell","Piemonte","amet@outlook.edu"),
  ("Jasmine Sloan","Madhya Pradesh","diam.at@protonmail.com"),
  ("Chloe Norton","Baja California","tortor.dictum@aol.net"),
  ("Francesca Morrow","Alajuela","amet.lorem@yahoo.com"),
  ("Boris Kelley","Atacama","diam.lorem@icloud.com"),
  ("Charissa Mendez","Limburg","eu.odio@yahoo.org"),
  ("Anne Dodson","North Island","congue.a@icloud.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Rogan Camacho","Hessen","torquent@icloud.ca"),
  ("Velma Humphrey","Lakshadweep","nisl.elementum@protonmail.com"),
  ("Raymond Nunez","Borno","sed.hendrerit@icloud.net"),
  ("Fletcher Roberson","Córdoba","integer.in.magna@google.net"),
  ("Belle Riddle","New South Wales","erat.eget@protonmail.couk"),
  ("Kevin Norton","Munster","luctus.sit.amet@icloud.ca"),
  ("Wing Hall","Friuli-Venezia Giulia","pede.nunc.sed@google.org"),
  ("Belle Russell","Nizhny Novgorod Oblast","odio.semper@google.net"),
  ("Aidan Soto","Lubuskie","donec.porttitor.tellus@google.couk"),
  ("Elizabeth Guy","Guanacaste","tristique.aliquet@hotmail.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Demetria Myers","Northern Cape","lorem.fringilla@yahoo.com"),
  ("Lucian Carpenter","South Island","morbi@aol.ca"),
  ("Hamilton Curry","Midi-Pyrénées","et.magna@icloud.org"),
  ("Cailin Giles","Delaware","amet@protonmail.net"),
  ("Chancellor Britt","Quảng Bình","tincidunt.adipiscing@protonmail.ca"),
  ("Salvador Finley","Queensland","ridiculus.mus@icloud.com"),
  ("Phillip Hancock","Cà Mau","vestibulum.mauris.magna@icloud.ca"),
  ("Declan Walton","Munster","iaculis.aliquet@protonmail.net"),
  ("Gisela Jefferson","Himachal Pradesh","vestibulum@aol.edu"),
  ("Stephen Sharp","Gilgit Baltistan","amet.ultricies.sem@aol.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Blaze Mitchell","Coahuila","nisi.sem@icloud.net"),
  ("Anthony Sanders","New Brunswick","tellus.phasellus@hotmail.couk"),
  ("Lee Roy","North Gyeongsang","aenean@outlook.edu"),
  ("Tad Nieves","Australian Capital Territory","non.luctus.sit@hotmail.couk"),
  ("Pearl Albert","Utah","lorem.ut.aliquam@hotmail.edu"),
  ("Inga Chaney","Kansas","leo.in@icloud.edu"),
  ("MacKensie Crosby","Munster","ultrices.sit@protonmail.com"),
  ("Edan Brock","West Region","imperdiet.dictum.magna@protonmail.couk"),
  ("Josiah Maxwell","North Region","dolor.nonummy.ac@google.net"),
  ("Ryder Alvarez","Soccsksargen","ridiculus.mus.proin@aol.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Ivan Beck","Magallanes y Antártica Chilena","donec.fringilla.donec@hotmail.edu"),
  ("Ezekiel Goodwin","Innlandet","laoreet.posuere@outlook.ca"),
  ("Garrett Dale","Khyber Pakhtoonkhwa","justo.praesent@aol.edu"),
  ("Holly Shields","Piemonte","eu@aol.net"),
  ("Gloria Turner","West Region","mauris.aliquam@google.edu"),
  ("Adam Ellison","Central Region","sed.et@outlook.org"),
  ("Upton Leon","Dalarnas län","ligula@hotmail.couk"),
  ("Teegan Gamble","Östergötlands län","lorem@google.ca"),
  ("Elizabeth Gallagher","Mpumalanga","non.lacinia.at@google.edu"),
  ("Autumn Head","Trøndelag","convallis.est@hotmail.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Patience Faulkner","Western Australia","aenean.sed@aol.ca"),
  ("Martin Boyer","Alajuela","augue.ut@aol.com"),
  ("Emily Horne","Ontario","magnis.dis@icloud.net"),
  ("Tobias Pearson","Bauchi","erat.vivamus@icloud.com"),
  ("Clark Mcintosh","Donetsk oblast","dolor.elit@outlook.com"),
  ("Imani O'Neill","Quebec","nunc.nulla.vulputate@protonmail.ca"),
  ("Karyn Mcbride","North Region","in.nec@protonmail.net"),
  ("Ralph Hammond","North Island","pellentesque.tincidunt@google.org"),
  ("Carter Stephens","Oaxaca","purus@icloud.couk"),
  ("Juliet Herring","Connacht","donec@hotmail.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Dalton Lindsey","Huáběi","arcu.vestibulum.ante@outlook.couk"),
  ("Ursula Bradford","Kaduna","hendrerit.consectetuer@protonmail.couk"),
  ("Rhiannon Moody","Xīnán","nulla@hotmail.couk"),
  ("Owen Griffith","Tyrol","vitae@outlook.com"),
  ("Tobias Saunders","San José","id.enim.curabitur@hotmail.ca"),
  ("Hilda Johnson","South Jeolla","nam.interdum@yahoo.org"),
  ("Olga Gilbert","Friesland","proin.vel@hotmail.edu"),
  ("Jeremy Gomez","West-Vlaanderen","ornare.in.faucibus@google.net"),
  ("Noah Russell","Connacht","lorem.sit.amet@google.com"),
  ("Candice Gill","Western Visayas","ridiculus.mus@icloud.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Dean Burns","Brussels Hoofdstedelijk Gewest","quam@aol.couk"),
  ("Yoshio Avery","Marche","neque.tellus@icloud.edu"),
  ("Mark French","Møre og Romsdal","posuere@google.org"),
  ("Rae Decker","Maule","magna.malesuada@icloud.net"),
  ("Ray Burns","South Jeolla","nulla.cras@icloud.edu"),
  ("Martin Mccarthy","Western Cape","mauris@icloud.edu"),
  ("Lilah Spence","Western Visayas","ipsum.phasellus@aol.couk"),
  ("Kevyn Fry","Mazowieckie","tincidunt.congue@protonmail.couk"),
  ("Mohammad Calderon","West Region","proin.ultrices@icloud.com"),
  ("Maggy Cotton","Sachsen-Anhalt","urna@hotmail.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Justin Burns","Paraíba","rutrum.eu.ultrices@google.ca"),
  ("Wynne Welch","Quebec","vel.venenatis@yahoo.ca"),
  ("Stephen Nunez","Donetsk oblast","semper.erat@protonmail.com"),
  ("Sasha Coffey","Piemonte","pede.malesuada@icloud.edu"),
  ("Lani Lambert","Tripura","eleifend@aol.com"),
  ("Jin Bender","Baden Württemberg","vel.sapien@google.edu"),
  ("Cody Fox","Jeju","pede.malesuada@protonmail.net"),
  ("Nissim Talley","Bolívar","amet@google.net"),
  ("Oleg Alford","İzmir","duis.volutpat.nunc@protonmail.net"),
  ("Shea Good","Lviv oblast","in.faucibus@protonmail.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Beatrice Shepard","Piura","libero.dui@icloud.org"),
  ("Tanek Barrett","Connacht","dolor.elit.pellentesque@protonmail.org"),
  ("Hyacinth Mccall","Caquetá","ante.lectus.convallis@outlook.com"),
  ("Amena Norton","Wielkopolskie","pede.cras@outlook.net"),
  ("Nita Garrett","Piura","sit.amet@yahoo.org"),
  ("Neve Warner","FATA","nunc.ullamcorper@outlook.org"),
  ("Kuame Mcknight","Kahramanmaraş","tristique.neque@icloud.couk"),
  ("Dylan Logan","La Libertad","mollis.phasellus@hotmail.couk"),
  ("Morgan Santana","Lubuskie","nulla.at.sem@yahoo.couk"),
  ("Oscar Mayo","Southeast Sulawesi","nisi.aenean@icloud.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Carolyn Ross","Limousin","risus@yahoo.net"),
  ("Yuli Morris","Troms og Finnmark","elementum@icloud.ca"),
  ("Vera Schultz","Tyrol","adipiscing.ligula.aenean@icloud.org"),
  ("August Clements","Magadan Oblast","fringilla@google.net"),
  ("Knox Buckley","Gilgit Baltistan","enim.gravida@hotmail.org"),
  ("Judith Martin","Los Ríos","leo.morbi@protonmail.com"),
  ("Ciaran Rodgers","Arica y Parinacota","mi.lorem.vehicula@icloud.edu"),
  ("Vernon Humphrey","Caraga","eleifend.cras@outlook.net"),
  ("Joy Sims","Lazio","placerat.augue@protonmail.edu"),
  ("Yasir Mitchell","Caldas","convallis.in.cursus@icloud.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Sharon Joyner","Tula Oblast","aliquet@yahoo.ca"),
  ("Hamish Fuller","Hatay","quisque@protonmail.org"),
  ("Cedric Fleming","Connacht","hendrerit.neque.in@protonmail.org"),
  ("Perry Lott","Orkney","id.magna.et@google.edu"),
  ("Kato Rivas","Gävleborgs län","auctor.mauris@aol.net"),
  ("Gillian Allison","Oost-Vlaanderen","molestie@protonmail.com"),
  ("Serena Kaufman","Ulster","ac@icloud.com"),
  ("Wesley Patton","West Region","lorem.ipsum@icloud.edu"),
  ("Amery Sherman","Bremen","pretium.neque@yahoo.net"),
  ("Nigel Carpenter","Tasmania","proin.sed@google.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Rogan Hurley","Schleswig-Holstein","malesuada.malesuada.integer@hotmail.com"),
  ("Zephr Vaughn","Lower Austria","diam@google.edu"),
  ("Kellie Cooley","Zhōngnán","aliquam.adipiscing@hotmail.net"),
  ("Jamal Velazquez","Murmansk Oblast","egestas.aliquam@yahoo.couk"),
  ("Denise Terrell","West Nusa Tenggara","aliquam@icloud.com"),
  ("Clare Dominguez","San Andrés y Providencia","nunc@aol.com"),
  ("Colt Payne","Punjab","ipsum.primis.in@google.edu"),
  ("Emma Graves","Abruzzo","mollis.vitae@protonmail.edu"),
  ("Kalia Bass","Agder","pellentesque@outlook.ca"),
  ("Kylee Blanchard","Lubelskie","conubia.nostra@icloud.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Dorian Taylor","Balochistan","curabitur.vel.lectus@google.org"),
  ("Brady Huber","Dōngběi","ante@yahoo.ca"),
  ("Karleigh Newton","Victoria","lectus@hotmail.com"),
  ("Josiah Wilkerson","Volyn oblast","eros.non.enim@hotmail.com"),
  ("Hiram Maynard","Kirov Oblast","dis@hotmail.com"),
  ("Veronica Diaz","Xīnán","quisque@yahoo.net"),
  ("Myra Beck","Marche","pharetra@google.edu"),
  ("Autumn Bentley","Aisén","lorem.tristique.aliquet@yahoo.couk"),
  ("Hamish Briggs","Astrakhan Oblast","nec.diam@aol.com"),
  ("Leila Conley","Nunavut","non.justo@yahoo.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Jordan Booth","Tomsk Oblast","integer.urna.vivamus@yahoo.edu"),
  ("Clarke Campos","Sindh","ac.facilisis@icloud.ca"),
  ("Abdul Garrison","Gilgit Baltistan","et@yahoo.couk"),
  ("Vladimir Hickman","Bayern","fermentum.arcu.vestibulum@icloud.org"),
  ("Odessa Vance","Katsina","elementum.purus@hotmail.org"),
  ("Ivy Ellis","Tyumen Oblast","nunc.ut.erat@google.couk"),
  ("Liberty Sears","Gilgit Baltistan","id.blandit.at@protonmail.org"),
  ("Barbara Rivas","Lombardia","pede.praesent.eu@hotmail.net"),
  ("Noble Erickson","Mexico City","eu.tellus@outlook.org"),
  ("Heather Mcmillan","Limón","phasellus.nulla.integer@hotmail.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Marsden Orr","Atacama","at.lacus@outlook.org"),
  ("Nora Little","Liguria","sed.nec@yahoo.net"),
  ("Rooney Wolfe","Drenthe","vel.turpis@hotmail.org"),
  ("Hilel Byers","Special Capital Region of Jakarta","fringilla@icloud.couk"),
  ("Brenda Park","British Columbia","ipsum.sodales@yahoo.edu"),
  ("Selma Logan","Konya","enim.sit@aol.com"),
  ("Dean Gilmore","Flevoland","dignissim.lacus.aliquam@outlook.edu"),
  ("Jorden Chen","West Region","vehicula.et@icloud.org"),
  ("Steel Vega","Cusco","et.netus@yahoo.org"),
  ("Wyoming Buck","South Chungcheong","enim.etiam.imperdiet@google.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Baker Giles","Kirkcudbrightshire","purus.nullam.scelerisque@yahoo.net"),
  ("Leandra Sargent","Guainía","tincidunt.tempus@google.net"),
  ("Ahmed Avila","Córdoba","arcu@aol.ca"),
  ("Rudyard Barton","Limburg","lorem.ut@outlook.com"),
  ("Brandon Hopper","Östergötlands län","lobortis@aol.net"),
  ("Kevin Walls","Jalisco","eu@icloud.ca"),
  ("Kalia Sanchez","Sachsen","mus.donec@icloud.couk"),
  ("Kaseem Alexander","Xīběi","risus.at.fringilla@aol.com"),
  ("Nash Beck","Gävleborgs län","vitae.velit@aol.net"),
  ("Yvonne Cote","West Java","maecenas.iaculis@yahoo.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Clarke Perkins","Heredia","inceptos.hymenaeos@aol.ca"),
  ("Violet Ruiz","Van","pellentesque.tellus.sem@hotmail.net"),
  ("Hamish Mullins","Victoria","pede.nunc.sed@hotmail.edu"),
  ("Quin Lang","North Island","tristique.ac@aol.couk"),
  ("Venus Davenport","Southwestern Tagalog Region","nam@outlook.couk"),
  ("Raphael Velazquez","Sumy oblast","egestas@yahoo.com"),
  ("Marshall O'donnell","Queensland","tempus.mauris@yahoo.couk"),
  ("Preston Pope","Michoacán","feugiat@protonmail.net"),
  ("Wallace Golden","Kyiv oblast","magna.lorem.ipsum@aol.org"),
  ("Dorian Vinson","Punjab","molestie@google.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Ulric Gordon","Caquetá","felis.donec@aol.org"),
  ("Julian Good","Gävleborgs län","libero@icloud.org"),
  ("Kelsey Morales","South Jeolla","integer.in.magna@icloud.com"),
  ("Zachary Watson","Araucanía","dictum.cursus@hotmail.couk"),
  ("Jenette Fitzgerald","Southeast Sulawesi","ac.orci.ut@google.couk"),
  ("Cheyenne Perkins","Bicol Region","cras.convallis.convallis@hotmail.org"),
  ("Katell Rios","Gia Lai","at.risus@icloud.couk"),
  ("Tamekah Lynch","Borno","lorem.vitae@icloud.couk"),
  ("Yeo Carrillo","Cartago","aliquam.adipiscing.lacus@protonmail.couk"),
  ("Demetrius Gibbs","Loreto","ac@icloud.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Blythe Rosales","Sachsen","feugiat.placerat.velit@google.org"),
  ("Evelyn Brooks","Pará","accumsan.interdum.libero@yahoo.ca"),
  ("Rebekah Glenn","Bali","etiam@protonmail.com"),
  ("Francesca Nelson","Xīběi","dignissim@google.org"),
  ("Chadwick Saunders","Poltava oblast","dolor.donec@outlook.ca"),
  ("Hannah Morrow","Galicia","accumsan.laoreet@hotmail.com"),
  ("Joelle Owen","Castilla y León","pellentesque.habitant.morbi@outlook.couk"),
  ("Breanna Byers","Oaxaca","augue.ac.ipsum@hotmail.ca"),
  ("Stone Moran","Noord Holland","elementum@yahoo.edu"),
  ("Justine Robertson","San José","scelerisque@protonmail.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Dolan Holmes","Jharkhand","sit.amet@yahoo.com"),
  ("Zahir Dixon","Arica y Parinacota","id.mollis@google.net"),
  ("Aquila Guzman","Illinois","at@aol.couk"),
  ("Janna Bishop","Maranhão","at.pede@hotmail.net"),
  ("Lucian Woodward","Cà Mau","ac@outlook.couk"),
  ("Kiara Alexander","Heredia","duis@hotmail.ca"),
  ("April Hubbard","Marche","tincidunt.nunc@aol.com"),
  ("Salvador Johns","Hamburg","magna@hotmail.ca"),
  ("Baker Fischer","Bremen","nec@yahoo.com"),
  ("Jamalia Ryan","Bahia","enim.commodo@outlook.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Hayley Cardenas","Vorarlberg","magna.sed@google.ca"),
  ("Michael Snow","Agder","maecenas.libero@protonmail.net"),
  ("Kai Knapp","Córdoba","massa.rutrum@yahoo.com"),
  ("Hedy Phelps","Limón","nisl.quisque@protonmail.edu"),
  ("Zena Simon","South Island","etiam.ligula.tortor@google.edu"),
  ("Nathan Mcdowell","Xīnán","fringilla.donec@aol.couk"),
  ("Macon Barron","Imo","sem.pellentesque.ut@aol.couk"),
  ("Ryan Patton","Cordillera Administrative Region","vel.vulputate.eu@outlook.com"),
  ("Orson Rogers","Quindío","class@icloud.org"),
  ("Lysandra Burris","Valle d'Aosta","ornare.lectus@google.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Charlotte Zimmerman","Veracruz","enim.nunc.ut@protonmail.edu"),
  ("Harding Mccray","Kirovohrad oblast","penatibus.et.magnis@yahoo.com"),
  ("Mira Wells","Podlaskie","felis@hotmail.couk"),
  ("Charles Bray","Tasmania","dolor@aol.couk"),
  ("Amena Randolph","Samsun","luctus.felis.purus@outlook.edu"),
  ("Ali Gill","Mpumalanga","pretium.et@google.ca"),
  ("Aphrodite Serrano","Soccsksargen","eu.eros.nam@icloud.net"),
  ("Mollie Marks","Jeju","facilisis.lorem@hotmail.ca"),
  ("Minerva Copeland","Eastern Visayas","hendrerit@icloud.edu"),
  ("Kelsey Mullins","Brandenburg","velit.dui@aol.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Thaddeus Hicks","Valle del Cauca","auctor@yahoo.ca"),
  ("Mallory Burch","Akwa Ibom","ac.nulla@yahoo.edu"),
  ("Sybil Clemons","Viken","dapibus@aol.ca"),
  ("Hasad Cooper","Queensland","nulla.integer@protonmail.com"),
  ("Richard Sparks","Lower Austria","elit@outlook.org"),
  ("Hector Holt","Leinster","phasellus.libero@hotmail.org"),
  ("Buckminster Mcclure","Sląskie","nunc.sollicitudin.commodo@icloud.couk"),
  ("Odysseus Moore","Bremen","nunc@aol.couk"),
  ("Molly Jordan","Zhytomyr oblast","convallis.convallis.dolor@outlook.org"),
  ("Alika Hurst","Bryansk Oblast","cursus.purus@outlook.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Cody Nunez","Maine","sagittis.lobortis@google.ca"),
  ("Yvette Harding","Alberta","cursus.non@aol.edu"),
  ("Austin Church","East Kalimantan","egestas.a@icloud.couk"),
  ("Stella Mckenzie","West Sumatra","gravida@icloud.org"),
  ("Myles Watts","Corse","arcu.vel@icloud.ca"),
  ("Macaulay Solis","Brussels Hoofdstedelijk Gewest","morbi@hotmail.couk"),
  ("Nicholas Wong","Jharkhand","ipsum.donec@icloud.ca"),
  ("Elaine Serrano","Ceará","sodales.at@protonmail.com"),
  ("Barclay Hopper","San Andrés y Providencia","porttitor.interdum@google.org"),
  ("Beatrice Wiggins","Bicol Region","cursus.vestibulum@protonmail.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Ivana Mclaughlin","Guerrero","integer@yahoo.org"),
  ("Ramona Lamb","Leinster","cursus.a@protonmail.com"),
  ("Germaine Goodwin","Saarland","ultricies.ligula@protonmail.ca"),
  ("Macey Hobbs","Santa Catarina","ligula.elit@icloud.edu"),
  ("Vera Hendricks","Ceará","fermentum.risus@yahoo.org"),
  ("William Montgomery","North Island","diam@hotmail.org"),
  ("Joseph Key","Xīběi","lacinia.vitae@google.edu"),
  ("Xantha Perry","North Region","lacus.aliquam@icloud.net"),
  ("Claire Craft","North-East Region","at.lacus.quisque@outlook.net"),
  ("Guy Madden","Chelyabinsk Oblast","porttitor.vulputate@aol.couk");
